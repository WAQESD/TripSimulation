<script setup>
import VMap from "../components/VMap.vue";
</script>

<template>
  <VMap></VMap>
</template>

<style scoped></style>
