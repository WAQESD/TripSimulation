<script setup></script>

<template>
  <span></span>
</template>

<style scoped>
span {
  display: inline-block;
  margin: 2px 8px 0 8px;
  width: 8px;
  height: 8px;
  border-radius: 8px;
  background-color: #9e9e9e;
}
</style>
