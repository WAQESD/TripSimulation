<script setup>
import { RouterView } from "vue-router";
import TheModal from "./commons/TheModal.vue";
</script>

<template>
  <TheModal></TheModal>
  <RouterView />
</template>

<style scoped></style>
